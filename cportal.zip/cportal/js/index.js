    // DEFINITION FOR SELECT DEPARTMENT TEMPLATE
    Vue.component('departmentselect',{
        template:"<select class='form-control'>"+
        "<option  selected disabled value=''>Select Department</option>"+
        "<option v-for='department in departments'>{{department}}</option>"+
        "</select>",
        data:function(){
            return{
                departments:['Security','Ushering','Machines & Setup','Evangelism','Choir']

            }
        }
    });

    // VUE INSTANCE DEFINITION FOR MEMBERS-DISPLAY
	var app = new Vue({
		el:'#members-display',
		data:{
			memberColumns:['#','Name','Telephone','Email','Country','Options'],
			memberDatas:[
				{name:'mark Anna',telephone:'0785334433',email:'mark@phaneroo.org',country:'uganda',departments:['ushering','evangelism']},
				{name:'peter Drucker',telephone:'0785334433',email:'peter@phaneroo.org',country:'uganda',departments:['evangelism','choir','ushering']},
				{name:'john Maxwell',telephone:'0785334433',email:'john@phaneroo.org',country:'japan',departments:['ushering']},
				{name:'paul Apostle',telephone:'0785334433',email:'paul@phaneroo.org',country:'uganda',departments:['evangelism','choir']},
				{name:'jacob Israel',telephone:'0785334433',email:'jacob@phaneroo.org',country:'uganda',departments:['ushering','children']},
				{name:'dickens Ochero',telephone:'0700112113',email:'dickens@phaneroo.org',country:'uganda',departments:['youth','children']}
				],
            countrys:['Uganda','Kenya','Sweden','China','Albania'],
            departments:['Security','Ushering','Machines & Setup','Evangelism','Choir'],
            
            // DISPLAY STATES FOR DIFFERENT PANELS
			addNewMemberState:false,
            viewMemberState:true,
            assignDepartmentState:false,

            selectedMemberIndex:0,
            departmentSearch:''

		},

		methods:{
            // SHOW ADD NEW MEMBER PANEL
			addNewMemberForm:function(){
				this.addNewMemberState=true;
                this.viewMemberState=false;
                this.assignDepartmentState=false;
            },
            // SHOW MEMBER DETAILS PANEL
			showMemberDetails:function(index){
				this.viewMemberState=true;
				this.addNewMemberState=false;
                this.assignDepartmentState=false;
				this.selectedMemberIndex=index;
            },
            // SHOW ASSIGN MEMBER DEPARTMENT
            assignMemberDepartment:function(){
				this.assignDepartmentState=true;
				this.addNewMemberState=false;
                this.viewMemberState=false;
            }
        },
        computed:{
            // FILTER MEMBERS BY DEPARTMENT ONLY
            filteredMembers:function(){
                return this.memberDatas.filter(memberData => {
                    return memberData.departments.join().toLowerCase().indexOf(this.departmentSearch.toLowerCase()) > -1
                 })
            }

        }
	})

